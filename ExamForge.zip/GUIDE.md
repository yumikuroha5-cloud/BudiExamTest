# ExamForge – Android Guide (no computer needed)

## A. Put it online with GitHub Pages (free)
1. Unzip: in "Files by Google", tap ExamForge.zip → Extract. You get 7 files (index.html, manifest.json, service-worker.js, icon-192.png, icon-512.png, questions.json, GUIDE.md).
2. In Chrome open github.com, sign up/log in. Tap ⋮ → "Desktop site" (easier buttons).
3. Tap + → New repository. Name: examforge. Choose Public. Tap Create repository.
4. Tap "uploading an existing file" (or Add file → Upload files). Select ALL extracted files (long-press to multi-select). Wait for uploads, tap Commit changes.
5. Settings → Pages → Source: "Deploy from a branch" → Branch: main, folder /(root) → Save.
6. After 1–2 minutes your app is at https://YOURNAME.github.io/examforge/

## B. Install on your phone
1. Open that link in Chrome and let it fully load (needs internet once).
2. Tap ⋮ → "Install app" / "Add to Home screen".
3. Turn on airplane mode and open it from the home screen – it works offline.

## C. Import a question bank
1. Create a .json file in the format of questions.json (any AI chatbot can generate it; paste questions.json as the template).
2. Save it to your phone, open ExamForge, tap "Import Question Bank", pick the file. The filename is shown on the dashboard.
3. The bank is stored in the browser, so it works offline. Errors are listed in plain language.

## D. Open on Windows/PC without internet
Double-click index.html (opens in your browser). Import and exams work; install/offline-caching needs the GitHub Pages link.

## Updating later
Edit/replace files on GitHub, and change CACHE='examforge-v1' to 'examforge-v2' in service-worker.js so phones fetch the new version.
